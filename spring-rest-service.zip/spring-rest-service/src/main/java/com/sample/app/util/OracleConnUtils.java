package com.sample.app.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class OracleConnUtils {

	public static Connection getOracleConnection() throws ClassNotFoundException, SQLException {

		String connectionURL = "jdbc:oracle:thin:@exa002ldccs02.rci.rogers.com:1528/ACP1DEV_SN";
		String userName = "bshall01";
		String password = "O$shARu02_02";
		return getOracleConnection(connectionURL, userName, password);
	}

	public static Connection getOracleConnection(String connectionURL, String userName, String password)
			throws SQLException, ClassNotFoundException {

		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection conn = DriverManager.getConnection(connectionURL, userName, password);
		return conn;
	}

}
